#!/usr/bin/env python

from __future__ import print_function
import sys, os
import random
from physics import *
import sml

GRAVITY = (0, -900)  # 900 = default

ROOMW = 200
ROOMH = 200

WALL_MASS = None  # None for unmovable
WALL_ELAS = 1.0

WALLS = [
    # name         x      y      w      h
	( 'floor',     0,    -5, ROOMW,     5 ),
	( 'ceil',      0, ROOMH, ROOMW,     5 ),
	( 'left',     -5,     0,     5, ROOMH ),
	( 'right', ROOMW,     0,     5, ROOMH ) ]

BLOCKW = 50
BLOCKH = 5
BLOCK_MASS = None
BLOCK_ELAS = 1.0

BLOCKS = [
    #     x      y  
	(    25,    50 ),
	(    25,   100 ),
	(    25,   150 ),
	(   125,    50 ),
	(   125,   100 ),
	(   125,   150 ) ]

BALLR = 1
BALL_MASS = 1.0
BALL_ELAS = 1.0

BALL_POS = (40, 170)
BALL_VEL = (50, 0)

RULES = [
'''sp {create-models
   (state <s> ^superstate nil
              ^svs <svs>)
   (<svs> ^spatial-scene <scn> ^command <c>)
   (<scn> ^child.id b1)
-->
   (<c> ^create-model <mx> <mz>)
   (<mx> ^name b1:px ^type em)
   (<mz> ^name b1:pz ^type em)
}
''',
'''sp {assign-models
   (state <s> ^superstate nil
              ^svs.command <c>)
   (<c> ^create-model <cm>)
   (<cm> ^name <name> ^status success)
-->
   (<c> ^assign-model <a>)
   (<a> ^name <name> ^inputs all ^outputs.<name> <d>)}
''']

def output_handler(id, world, agent, phase):
	world.step()
	sgel = world.get_sgel()
	agent.SendSVSInput(sgel)
	
class Experiment:
	def __init__(self):
		self.cli = sml.cli()
		self.agent = self.cli.agent
		self.kernel = self.cli.kernel
		
		self.cli.execute('waitsnc -e')
		for r in RULES:
			self.cli.execute(r)
		self.cli.execute('run 2')

		self.output_event = None
	
	def reset(self):
		if self.output_event != None:
			self.agent.UnregisterForRunEvent(self.output_event)
		
		self.world = World(GRAVITY)
		space = self.world.space

		for w in WALLS:
			wall = Box(space, w[0], w[1:3], WALL_MASS, WALL_ELAS, w[3:5])
			self.world.add(wall, (0, 0))

		blkdims = (BLOCKW, BLOCKH)
		for i, b in enumerate(BLOCKS):
			name = 'p{}'.format(i)
			blk = Box(space, name, b[0:2], BLOCK_MASS, BLOCK_ELAS, blkdims)
			self.world.add(blk, (0, 0))

		ball = Ball(space, 'b1', BALL_POS, BALL_MASS, BALL_ELAS, BALLR)
		self.world.add(ball, BALL_VEL)
		
		# Need to do this first step so that all velocities
		# have real values the first time Soar sees them
		self.world.step()
		init_input = self.world.get_sgel()
		self.agent.SendSVSInput(init_input)
		self.output_event = self.agent.RegisterForRunEvent(sml.sml.smlEVENT_AFTER_OUTPUT_PHASE, output_handler, self.world)
	
	def run(self):
		self.reset()
		self.cli.execute('svs learn on')
		self.cli.execute('svs 0 learn_models on')
		self.cli.repl()

if __name__ == '__main__':
	exp = Experiment()
	exp.run()
	