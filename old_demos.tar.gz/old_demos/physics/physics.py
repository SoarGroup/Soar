from __future__ import print_function
import pymunk as pm

def collision_handler(space, arbiter):
	for s in arbiter.shapes:
		name = s.owner.name
		body = s.owner.body
		#print('collide {} {} {}'.format(name, body.velocity[0], body.velocity[1]))
		#s.owner.pre_vel = (body.velocity[0], body.velocity[1])
		s.owner.pre_vel = (body.velocity[0], body.velocity[1] - 4.5)
	return True

class Ball:
	def __init__(self, space, name, pos, mass, elas, radius):
		self.added = False
		self.name = name
		self.space = space
		self.radius = radius
		moment = pm.moment_for_circle(mass, 0, radius)
		self.body = pm.Body(mass, moment)
		self.body.position = pos
		self.shape = pm.Circle(self.body, radius)
		self.shape.elasticity = elas
		self.shape.owner = self
		self.space.add(self.body, self.shape)
		self.pre_vel = None
		
	def get_sgel(self):
		if not self.added:
			sgel = "a {} world b {:.20f}".format(self.name, self.radius)
			self.added = True
		else:
			sgel = "c " + self.name
		
		sgel += " p {:.20f} 0 {:.20f}".format(*self.body.position) + '\n'
		
		if self.pre_vel != None:
			v = self.pre_vel
			self.pre_vel = None
		else:
			v = self.body.velocity
		
		sgel += 'p {} vx {:.20f}'.format(self.name, v[0]) + '\n'
		sgel += 'p {} vz {:.20f}'.format(self.name, v[1])
		return sgel

class Box:
	def __init__(self, space, name, pos, mass, elas, dims):
		w, h = dims
		self.added = False
		self.name = name
		self.space = space
		self.pos = pos
		if mass == None:
			self.static = True
			
		if self.static:
			self.body = pm.Body()
		else:
			moment = pm.moment_for_box(mass, w, h)
			self.body = pm.Body(mass, moment)
		
		self.body.position = pos
		verts = [(0,0), (0,h), (w,h), (w,0)]
		self.shape = pm.Poly(self.body, verts)
		self.shape.elasticity = elas
		self.shape.owner = self
		
		if self.static:
			self.space.add(self.shape)
		else:
			self.space.add(self.body, self.shape)
		
		verts3d = [(x, -5, y) for x, y in verts] + [(x, 5, y) for x, y in verts]
		self.svs_verts = ' '.join('{:.20f} {:.20f} {:.20f}'.format(*v) for v in verts3d)
	
	def get_sgel(self):
		if self.static and self.added:
			return ''
		
		if not self.added:
			sgel = "a {} world v {}".format(self.name, self.svs_verts)
			self.added = True
		else:
			sgel = "c " + self.name
		
		sgel += " p {:.20f} 0 {:.20f}".format(*self.body.position)
		return sgel

class World:
	def __init__(self, g):
		self.objs = []
		self.space = pm.Space()
		self.space.gravity = g
		self.space.add_collision_handler(0, 0, begin=collision_handler, pre_solve=None, post_solve=None)
		self.dt = 1.0/200.0

	def add(self, obj, vel = (0, 0)):
		self.objs.append(obj)
		obj.body.apply_impulse(vel)
	
	def step(self):
		px = []
		for o in self.objs:
			px.append(o.body.position[0] + self.dt * o.body.velocity[0])
			
		self.space.step(self.dt)
		for i, o in enumerate(self.objs):
			dx = px[i] - o.body.position[0]
			if dx != 0:
				print('{}.x discrepancy = {}'.format(o.name, dx))
		
	def get_sgel(self):
		return '\n'.join(o.get_sgel() for o in self.objs)
