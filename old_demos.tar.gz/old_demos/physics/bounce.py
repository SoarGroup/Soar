#!/usr/bin/python

from __future__ import print_function
import sys, os
import random
from physics import *
import sml

def output_handler(id, world, agent, phase):
	world.step()
	sgel = world.get_sgel()
	agent.SendSVSInput(sgel)

def reinit_handler(id, experiment, agent):
	experiment.reset()
	
def gen_model_rules(type, inputs, predict):
	gen_model_rules.count += 1
	
	if inputs == 'all':
		input_str = 'all'
	else:
		input_str = '.'.join(inputs)
	
	create_rule = '''
	sp {{create-model-{}
	   (state <s> ^superstate nil ^svs.command <c>)
	-->
	   (<c> ^create-model <m>)
	   (<m> ^type {} ^name {})}}
	'''.format(gen_model_rules.count, type, predict)

	assign_rule = '''
	sp {{assign-model-{0}
	   (state <s> ^superstate nil ^svs.command <c>)
	-->
	   (<c> ^assign-model <a>)
	   (<a> ^name {1} ^inputs {2} ^outputs.{1} <dummy>)}}
	'''.format(gen_model_rules.count, predict, input_str)
	
	return create_rule, assign_rule

gen_model_rules.count = 0
	
class Experiment:
	def __init__(self, config):
		self.config = config
		self.cli = sml.cli()
		self.agent = self.cli.agent
		self.kernel = self.cli.kernel
		
		self.cli.execute('waitsnc -e')
		create_rules, assign_rules = zip(*[gen_model_rules(t, i, o) for t, i, o in self.config['models']])
		for r in create_rules:
			self.cli.execute(r)
		self.cli.execute('run 2')
		self.cli.execute('excise -a')
		for r in assign_rules:
			self.cli.execute(r)

		self.output_event = None
		self.kernel.RegisterForAgentEvent(sml.sml.smlEVENT_AFTER_AGENT_REINITIALIZED, reinit_handler, self)
		self.train = True
		
	
	def reset(self):
		if self.output_event != None:
			self.agent.UnregisterForRunEvent(self.output_event)
		
		self.world = World(self.config['gravity'])
		space = self.world.space
		
		for type, name, pos, mass, elas, dims, vel in self.objs:
			obj = type(space, name, pos, mass, elas, dims)
			self.world.add(obj, vel)
		
		# Need to do this first step so that all velocities
		# have real values the first time Soar sees them
		self.world.step()
		init_input = self.world.get_sgel()
		self.agent.SendSVSInput(init_input)
		self.output_event = self.agent.RegisterForRunEvent(sml.sml.smlEVENT_AFTER_OUTPUT_PHASE, output_handler, self.world)
	
	def run(self):
		for scn in self.config.get('train_scns', []):
			self.objs = scn[1:]
			self.cli.execute('init')
			self.cli.execute('svs learn on')
			self.cli.execute('svs 0 learn_models on')
			self.cli.repl()
			sys.exit(0)
			self.cli.execute('run {}'.format(scn[0]))

		self.cli.repl()

		for scn in self.config.get('test_scns', []):
			self.objs = scn[1:]
			self.cli.execute('init')
			self.cli.execute('svs 0 test_models on')
			self.cli.execute('run {}'.format(scn[0]))
			self.cli.repl()

CONFIGS = {
'full_bounce' : {
	'gravity' : (0, -900),
	'train_scns' : [
		(
			400,
			# type name  pos     mass   elas   dims      vel
			(Ball, 'b1', (1, 5), 1,     1,     1,        (0, 0) ),
			(Box,  'g',  (0, 0), None,  1,     (100, 1), (0, 0) ),
			(Box,  'd',  (0,-3), None,  1,     (1, 1), (0, 0) ),
		),
		(
			400,
			# type name  pos     mass   elas   dims      vel
			(Ball, 'b1', (2, 3), 1,     1,     1,        (0, 0) ),
			(Box,  'g',  (0, 0), None,  1,     (100, 1), (0, 0) ),
		),
	],
	'test_scns' : [
		(
			100,
			# type name  pos     mass   elas   dims      vel
			(Ball, 'b1', (3, 1), 1,     1,     1,        (0, 0) ),
			(Box,  'g',  (0, 0), None,  1,     (100, 1), (0, 0) ),
		),
		(
			100,
			# type name  pos     mass   elas   dims      vel
			(Ball, 'b1', (5, 6), 1,     1,     1,        (0, 0) ),
			(Box,  'g',  (0, 0), None,  1,     (100, 1), (0, 0) ),
		),
	],
	'models' : [
		# type   inputs    output
		('em',   'all',    'b1:vz'  ),
	],
},
'lossy_bounce' : {
	'gravity' : (0, -900),
	'train_scns' : [
		(
			400,
			# type name  pos     mass   elas   dims      vel
			(Ball, 'b1', (6, 4), 1,     .95,     1,        (15, 0) ),
			(Box,  'g',  (0, 0), None,  .95,     (100, 1), (0, 0) ),
		),
	],
	'test_scns' : [],
	'models' : [
		# type   inputs    output
		('em',   'all',    'b1:vz'  ),
		#('em',   'all',    'b1:pz'  ),
	],
},
'lossy_bounce_gen' : {
	'gravity' : (0, -900),
	'train_scns' : [
		(
			400,
			# type name  pos     mass   elas   dims      vel
			(Ball, 'b1', (-2, 5), 1,     .9,     1,        (0, 0) ),
			(Box,  'g',  (0, 0), None,  .9,     (100, 1), (0, 0) ),
		),
		(
			400,
			# type name  pos     mass   elas   dims      vel
			(Ball, 'b1', (2, 4), 1,     .9,     1,        (0, 0) ),
			(Box,  'g',  (0, 0), None,  .9,     (100, 1), (0, 0) ),
		),
	],
	'test_scns' : [
		(
			100,
			# type name  pos     mass   elas   dims      vel
			(Ball, 'b1', (5, 10), 1,     .9,     1,        (0, 0) ),
			(Box,  'g',  (0, 0), None,  .9,     (100, 1), (0, 0) ),
		),
		(
			100,
			# type name  pos     mass   elas   dims      vel
			(Ball, 'b1', (10, 3), 1,     .9,     1,        (0, 0) ),
			(Box,  'g',  (0, 0), None,  .9,     (100, 1), (0, 0) ),
		),
	],
	'models' : [
		# type   inputs    output
		('em',   'all',    'b1:vz'  ),
		('em',   'all',    'b1:pz'  ),
	],
},
'forward_lossy_bounce_gen' : {
	'gravity' : (0, -900),
	'train_scns' : [
		(
			300,
			# type name  pos     mass   elas   dims      vel
			(Ball, 'b1', (-2, 10), 1,     .9,     1,       (1.0, 0) ),
			(Box,  'g',  (0, 0), None,  .9,     (100, 1), (0, 0) ),
		),
		(
			300,
			# type name  pos     mass   elas   dims      vel
			(Ball, 'b1', (2, 5), 1,     .9,     1,        (-1.0, 0) ),
			(Box,  'g',  (0, 0), None,  .9,     (100, 1), (0, 0) ),
		),
	],
	'test_scns' : [
		(
			100,
			# type name  pos     mass   elas   dims      vel
			(Ball, 'b1', (5, 10), 1,     .9,     1,       (2.0, 0) ),
			(Box,  'g',  (0, 0), None,  .9,     (100, 1), (0, 0) ),
		),
	],
	'models' : [
		# type   inputs    output
		('em',   'all',    'b1:vz'  ),
		('em',   'all',    'b1:pz'  ),
	],
},
'2_balls_full_bounce' : {
	'gravity' : (0, -900),
	'train_scns' : [
		(
			400,
			# type name  pos        mass   elas   dims      vel
			(Ball, 'b1', (0, 5),    1,     1,     1,        (0, 0) ),
			(Ball, 'b2', (3, 3),    1,     1,     1,        (0, 0) ),
			(Box,  'g',  (-50, -1), None,  1,     (100, 1), (0, 0) ),
			(Box,  'w',  (-2, 0),   None,  1,     (1, 10), (0, 0) ),
		),
	],
	'test_scns' : [],
	'models' : [
		# type   inputs    output
		('em',   'all',    'b1:vz'  ),
	],
},
'1_ball_full_bounce_steps' : {
	'gravity' : (0, -900),
	'train_scns' : [
		(
			400,
			# type name  pos        mass   elas   dims      vel
			(Ball, 'b1', (3.2,  5),    1,     1,     1,        (15,0)),
			(Box,  's1', (0,  0),    None,  1,     (5, 1),   (0,0)),
			(Box,  's2', (5, -3),    None,  1,     (5, 1),   (0,0)),
			(Box,  's3', (10,-6),    None,  1,     (5, 1),   (0,0)),
			
		),
	],
	'test_scns' : [],
	'models' : [
		('em', 'all', 'b1:vz'),
	]
},
}

if __name__ == '__main__':
	#exp = Experiment(CONFIGS['full_bounce'])
	exp = Experiment(CONFIGS['lossy_bounce'])
	#exp = Experiment(CONFIGS['1_ball_full_bounce_steps'])
	exp.run()
