#include <iostream>
#include <sml_Client.h>

using namespace std;
using namespace sml;

int main(int argc, char *argv[]) {
	Kernel *k = Kernel::CreateKernelInCurrentThread();
	Agent *a = k->CreateAgent("arst");
	a->ExecuteCommandLine("waitsnc -e");
	
	string line;
	while (getline(cin, line)) {
		a->SendSVSInput(line);
		a->ExecuteCommandLine("step");
	}
}
