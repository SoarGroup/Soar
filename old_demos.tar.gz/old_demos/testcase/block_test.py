import sys, os
import random

for d in os.environ.get('LD_LIBRARY_PATH', '').split(':'):
	if os.path.exists(os.path.join(d, '_Python_sml_ClientInterface.so')):
		sys.path.append(d)
		break

import sml

DELTA = 1
MINPOS = 0
MAXPOS = 200
CUBESIZE = 10
HALFCUBE = CUBESIZE / 2.0
NOBJS = 3;

def cube_verts(h, w, d):
	h2 = h / 2
	w2 = w / 2
	d2 = d / 2
	
	return [ -h2, -w2, -d2,
	          h2, -w2, -d2,
	          h2,  w2, -d2,
	         -h2,  w2, -d2,
	         -h2, -w2,  d2,
	          h2, -w2,  d2,
	          h2,  w2,  d2,
	         -h2,  w2,  d2 ]

def overlap(a1, a2, b1, b2):
	return a1 <= b1 < a2 or b1 <= a1 < b2

def dist(p1, p2):
	return sum((x1 - x2) ** 2 for x1, x2 in zip(p1, p2))

def check_bounds(a, b):
	return MINPOS <= a <= b <= MAXPOS

class Cube:
	def __init__(self, name, solid=True, h = CUBESIZE, w = CUBESIZE, d = CUBESIZE):
		self.name = name
		self.added = False;
		self.verts = cube_verts(h, w, d)
		self.dims = (h, w, d)
		self.pos = [0.0, 0.0, 0.0]
		self.solid = solid
		self.dirty = True
	
	def get_sgel(self):
		if not self.dirty:
			return ''
		
		if not self.added:
			sgel = "a %s world v %s " % (self.name, ' '.join(str(x) for x in self.verts))
			self.added = True
		else:
			sgel = "c %s " % self.name
		
		print self.name, self.pos
		sgel += "p %f %f %f" % (self.pos[0], self.pos[1], self.pos[2])
		self.dirty = False
		return sgel
	
	def move(self, offsets):
		for i in range(3):
			self.pos[i] += offsets[i]
		self.dirty = True
	
	def move_to(self, pos):
		self.pos = pos
		self.dirty = True

	def min(self):
		return [ self.pos[i] - self.dims[i] / 2 for i in range(3) ]
	
	def max(self):
		return [ self.pos[i] + self.dims[i] / 2 for i in range(3) ]
		
	def intersects(self, b):
		amin = self.min()
		amax = self.max()
		bmin = b.min()
		bmax = b.max()
		for i in range(3):
			if not overlap(amin[i], amax[i], bmin[i], bmax[i]):
				return False
		return True
		
class World:
	def __init__(self, cursor, cubes):
		self.cursor = cursor
		self.cubes = cubes
	
	def get_sgel(self):
		sgel = []
		sgel.append(self.cursor.get_sgel())
		for c in self.cubes:
			sgel.append(c.get_sgel())
		return '\n'.join(sgel)
	
	def input(self, d):
		self.cursor.move(d)
		for c in self.cubes:
			if c.solid and self.cursor.intersects(c):
				# There are six possible positions for the cube that resolve the collision,
				# 2 for each dimension. Move it to the closest one.
				positions = []
				for i in range(3):
					p1 = c.pos[:]; p2 = c.pos[:]
					p1[i] = self.cursor.pos[i] - self.cursor.dims[i] / 2 - c.dims[i] / 2
					p2[i] = self.cursor.pos[i] + self.cursor.dims[i] / 2 + c.dims[i] / 2
					positions.append(p1)
					positions.append(p2)
				
				dists = [ dist(c.pos, p) for p in positions ]
				closest = min(zip(dists, positions))[1]
				dpos = [x1 - x2 for x1, x2 in zip(closest, c.pos)]
				c.move(dpos)
				#assert not self.cursor.intersects(c)
		
	def proc_input(self, input):
		d = [0, 0, 0]
		for line in input.split('\n'):
			fields = line.split()
			if len(fields) < 2:
				continue
			
			name = fields[0]
			try:
				val = float(fields[1])
			except ValueError:
				print >>sys.stderr, 'not a number: ', fields[1]
				continue
				
			if name == 'dx':
				d[0] = val
			elif name == 'dy':
				d[1] = val
			elif name == 'dz':
				d[2] = val
		
		self.input(d)

def output_handler(id, world, agent, phase):
	out = agent.GetSVSOutput()
	print "<- output ->"
	print out
	
	world.proc_input(out)
	inp = world.get_sgel()
	agent.SendSVSInput(inp)

if __name__ == '__main__':
	b1 = Cube('b1', True)
	
	extents = CUBESIZE * 5
	others = []
	for i in range(NOBJS):
		b = Cube('b%d' % (i + 2), True)
		b.move_to([random.uniform(-extents, extents), random.uniform(-extents, extents), 0])
		others.append(b)
		
	w = World(b1, others)
	
	cli = sml.cli()
	cli.agent.SendSVSInput('o dx -1 1 0 .1 dy -1 1 0 .1')
	init_input = w.get_sgel()
	cli.agent.SendSVSInput(init_input)
	cli.agent.RegisterForRunEvent(sml.sml.smlEVENT_AFTER_OUTPUT_PHASE, output_handler, w, True)
	cli.execute('source block_agent.soar')
	cli.run()
	
