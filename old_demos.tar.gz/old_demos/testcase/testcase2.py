import sys, os
import random
import sml

count = 0

def output_handler(id, world, agent, phase):
	global count
	if count == 5:
		agent.SendSVSInput('d b1')
	count += 1

if __name__ == '__main__':
	cli = sml.cli()
	cli.agent.SendSVSInput('''
a b1 world v 0 0 0 0 0 1 0 1 0 0 1 1 1 0 0 1 0 1 1 1 0 1 1 1 p 1 1 1
a b2 world v 0 0 0 0 0 1 0 1 0 0 1 1 1 0 0 1 0 1 1 1 0 1 1 1 p 0 0 0''')

	cli.agent.RegisterForRunEvent(sml.sml.smlEVENT_AFTER_OUTPUT_PHASE, output_handler, None, True)
	cli.execute('source agent2.soar')
	cli.run()
	
