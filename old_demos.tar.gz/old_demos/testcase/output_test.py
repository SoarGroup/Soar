import sys, os
import sml

def output_handler(id, world, agent, phase):
	print('-------------')
	print(agent.GetSVSOutput())
	print('=============')

if __name__ == '__main__':
	cli = sml.cli()
	cli.agent.SendSVSInput('o vx 0 1 0 0.1 vy 3 4 3 0.1')
	cli.agent.RegisterForRunEvent(sml.sml.smlEVENT_AFTER_OUTPUT_PHASE, output_handler, None, True)
	cli.execute('sp {rand (state <s> ^superstate nil ^svs.command <cmd>) --> (<cmd> ^random_control <r>)}')
	cli.run()
	
