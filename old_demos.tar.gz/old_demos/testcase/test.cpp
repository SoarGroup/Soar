#include <iostream>
#include <sstream>
#include <cstdlib>
#include <sml_Client.h>

using namespace std;
using namespace sml;

string strip(string s, string lc, string rc) {
    size_t b, e;
    b = s.find_first_not_of(lc);
    e = s.find_last_not_of(rc);
    return s.substr(b, e - b + 1);
}

void printcb(smlPrintEventId id, void *d, Agent *a, char const *m) {
    cout << strip(m, "\n", "\n\t ") << endl;
}

void output_handler(smlRunEventId id, void *pUserData, Agent *a, smlPhase phase) {
	static int count = 0;
	if (count++ == 3) {
		a->SendSVSInput("d b1");
	}
}

int main() {
	Kernel *k = Kernel::CreateKernelInNewThread();
	Agent *a = k->CreateAgent("arst");
	
    a->RegisterForPrintEvent(smlEVENT_PRINT, printcb, NULL);
	a->RegisterForRunEvent(smlEVENT_AFTER_OUTPUT_PHASE, &output_handler, NULL, true);
	
	a->SendSVSInput("a b1 world v 0 0 0 0 0 1 0 1 0 0 1 1 1 0 0 1 0 1 1 1 0 1 1 1");
	a->SendSVSInput("a b2 world v 0 0 0 0 0 1 0 1 0 0 1 1 1 0 0 1 0 1 1 1 0 1 1 1");
	a->ExecuteCommandLine("source agent2.soar");
	for (int i = 0; i < 10; ++i) {
		a->ExecuteCommandLine("step");
	}
	return 0;
}
