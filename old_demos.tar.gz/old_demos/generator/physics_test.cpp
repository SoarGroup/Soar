#include <iostream>
#include <unistd.h>
#include <chipmunk/chipmunk.h>

using namespace std;

int main(void) {
	cpSpace *space = cpSpaceNew();
	
	cpFloat radius = 5;
	cpFloat mass = 1;
	
	// The moment of inertia is like mass for rotation
	// Use the cpMomentFor*() functions to help you approximate it.
	cpFloat moment = cpMomentForCircle(mass, 0, radius, cpvzero);
	
	cpBody *ball1Body = cpSpaceAddBody(space, cpBodyNew(mass, moment));
	cpBody *ball2Body = cpSpaceAddBody(space, cpBodyNew(mass, moment));
	cpBodySetPos(ball1Body, cpv(0, 0));
	cpBodySetPos(ball2Body, cpv(10, 10));
	
	cpShape *ball1Shape = cpSpaceAddShape(space, cpCircleShapeNew(ball1Body, radius, cpvzero));
	cpShape *ball2Shape = cpSpaceAddShape(space, cpCircleShapeNew(ball2Body, radius, cpvzero));
	cpShapeSetFriction(ball1Shape, 0);
	cpShapeSetFriction(ball2Shape, 0);
	
	cout << "clear" << endl;
	cout << "s1 a ball1 world b 5 p 0 0 0" << endl;
	cout << "s1 a ball2 world b 5 p 1 1 0 " << endl;
	
	cpFloat timeStep = 1.0/60.0;
	for(cpFloat time = 0; time < 2; time += timeStep){
		cpVect p1 = cpBodyGetPos(ball1Body);
		cpVect p2 = cpBodyGetPos(ball2Body);
		cpVect v1 = cpBodyGetVel(ball1Body);
		cpVect v2 = cpBodyGetVel(ball2Body);
		cout << "s1 c ball1 p " << p1.x << " " << p1.y << " 0.0" << endl;
		cout << "s1 c ball2 p " << p2.x << " " << p2.y << " 0.0" << endl;
		
		cpSpaceStep(space, timeStep);
		usleep(500);
	}
	
	// Clean up our objects and exit!
	cpShapeFree(ball1Shape);
	cpShapeFree(ball2Shape);
	cpBodyFree(ball1Body);
	cpBodyFree(ball2Body);
	cpSpaceFree(space);
	
	return 0;
}
