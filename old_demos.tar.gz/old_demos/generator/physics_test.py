from __future__ import print_function
import sys
import math
import time
import random as rnd
import pymunk as pm
import numpy as np
import matplotlib.pyplot as plt

la = np.linalg

NTRAIN = 1000
NTEST = 100
RADIUS = 5.0
MASS = 1
ELASTICITY = 1
FRICTION = 0

def weighted_least_squares(X, Y, w):
	W = np.diag(w)
	Z = np.dot(W, X)
	V = np.dot(W, Y)
	return la.lstsq(Z, V)
	
def gen_linear_data(xdim, ydim, n, noise_std):
	X = np.random.rand(n, xdim) * 10
	W = np.random.rand(xdim, ydim)
	Y = np.dot(X, W) + np.random.normal(0, noise_std, (n, ydim))
	return X, Y, W

def join_vec2(*args):
	result = []
	for a in args:
		result.append(a[0])
		result.append(a[1])
	return result
	
class LWR:
	def __init__(self, X, Y, k, kernel = (lambda x: 1.0 / (x ** 3))):
		self.X = X
		self.Y = Y
		self.k = k
		self.kernel = kernel
		#self.xcovinv = np.eye(self.X.shape[1])
		self.xcovinv = la.inv(np.cov(self.X, rowvar = 0))
		#self.xcovinv = np.diag(np.diagonal(np.cov(self.X, rowvar=0)))
	
	def nearest(self, x):
		#import pdb; pdb.set_trace()
		dists = np.apply_along_axis(la.norm, 1, self.X - x)
		#dists = np.apply_along_axis(lambda xd: math.sqrt(np.dot(np.dot(xd, self.xcovinv), np.transpose(xd))), 1, self.X - x)
		nn = np.argsort(dists)[:self.k]
		return nn, dists[nn]
	
	def predict(self, x):
		nn, dists = self.nearest(x)
		trainx = self.X[nn]
		trainy = self.Y[nn]
		weights = np.array([self.kernel(d) for d in dists])
		for i, w in enumerate(weights):
			if np.isposinf(w):
				return trainy[i]
		
		coeffs, residuals, rank, s = weighted_least_squares(trainx, trainy, weights)
		return np.dot(x, coeffs)

# Ordinary least squares is terrible. LWR does a little better with a
# very focused kernel, but not much better. I think the problem here is
# that Euclidean distance is just not the right similarity metric.
def two_balls(show = False):
	dist = 12.0
	
	b2pos = pm.Vec2d(0, dist)	
	max_angle = math.atan(2 * RADIUS / dist)
	a = rnd.uniform(-max_angle, max_angle)
	mag = rnd.uniform(1, 5)
	v = pm.Vec2d(0, -mag).rotated(a)
	
	# rotate the entire system around the origin
	rot = rnd.uniform(0, 360)
	b2pos.rotate_degrees(rot)
	v.rotate_degrees(rot)
	
	# The moment of inertia is like mass for rotation
	# Use the cpMomentFor*() functions to help you approximate it.
	moment = pm.moment_for_circle(MASS, 0, RADIUS)
	
	b1 = pm.Body(MASS, moment)
	b2 = pm.Body(MASS, moment)
	s1 = pm.Circle(b1, RADIUS)
	s2 = pm.Circle(b2, RADIUS)
	
	offset = pm.Vec2d(rnd.uniform(-5, 5), rnd.uniform(-5, 5))
	b1.position = offset
	b1_orig_pos = b1.position
	b2.position = b2pos + offset
	b2.apply_impulse(v)
	s1.friction = FRICTION
	s1.elasticity = ELASTICITY
	s2.friction = FRICTION
	s2.elasticity = ELASTICITY
	
	space = pm.Space()
	space.add(b1, b2, s1, s2)
	
	if show:
		print('clear')
		print('s1 a ball1 world b {} p {} {} 0'.format(RADIUS, *b1.position))
		print('s1 a ball2 world b {} p {} {} 0'.format(RADIUS, *b2.position))
	
	dt = 1.0/60.0
	while True:
		if show:
			time.sleep(dt)
			print('s1 c ball1 p {} {} 0'.format(*b1.position))
			print('s1 c ball2 p {} {} 0'.format(*b2.position))
			print(b1.position, b1.velocity, b2.position, b2.velocity, file=sys.stderr)
		
		if not show and b1.velocity != (0, 0):
		#if b1.velocity != (0, 0):
			break
		
		prev_pos = tuple(b2.position)
		prev_vel = tuple(b2.velocity)
		space.step(dt)
	
	x = np.array(join_vec2(b1_orig_pos, prev_pos, prev_vel))
	y = np.array(join_vec2(b1.velocity, b2.velocity))
	dy = np.array(join_vec2(b1.velocity, b2.velocity - prev_vel))
	return x, y, dy

# Same setup as above, except one ball is unmovable. It seems like OLS
# doesn't learn it well, but LWR with anything other than a constant
# weighting is two orders of magnitude more accurate.
def two_balls_static(show = False):
	dist = 12.0
	
	b2pos = pm.Vec2d(0, dist)	
	max_angle = math.atan(2 * RADIUS / dist)
	a = rnd.uniform(-max_angle, max_angle)
	mag = rnd.uniform(1, 5)
	v = pm.Vec2d(0, -mag).rotated(a)
	
	# rotate the entire system around the origin
	rot = rnd.uniform(0, 360)
	b2pos.rotate_degrees(rot)
	v.rotate_degrees(rot)
	
	# The moment of inertia is like mass for rotation
	# Use the cpMomentFor*() functions to help you approximate it.
	moment = pm.moment_for_circle(MASS, 0, RADIUS)
	
	b1 = pm.Body()
	b2 = pm.Body(MASS, moment)
	s1 = pm.Circle(b1, RADIUS)
	s2 = pm.Circle(b2, RADIUS)
	
	offset = pm.Vec2d(rnd.uniform(-5, 5), rnd.uniform(-5, 5))
	b1.position = offset
	b2.position = b2pos + offset
	b2.apply_impulse(v)
	s1.friction = FRICTION
	s1.elasticity = ELASTICITY
	s2.friction = FRICTION
	s2.elasticity = ELASTICITY
	
	space = pm.Space()
	space.add_static(s1)
	space.add(b2, s2)
	
	if show:
		print('clear')
		print('s1 a ball1 world b {} p {} {} 0'.format(RADIUS, *b1.position))
		print('s1 a ball2 world b {} p {} {} 0'.format(RADIUS, *b2.position))
	
	dt = 1.0/60.0
	while True:
		if show:
			time.sleep(dt)
			print('s1 c ball1 p {} {} 0'.format(*b1.position))
			print('s1 c ball2 p {} {} 0'.format(*b2.position))
			print(b1.velocity, b2.velocity, file=sys.stderr)
		
		prev_pos = tuple(b2.position)
		prev_vel = tuple(b2.velocity)
		space.step(dt)
		if not show and b2.velocity != v:
			break
	
	x = np.array(join_vec2(prev_pos, prev_vel))
	y = np.array(join_vec2(b2.velocity))
	yd = np.array(join_vec2(b2.velocity - prev_vel))
	return x, y, yd

# Everything seems to work well, regardless of whether the block is
# rotated or not.
def ball_wall(box_rot, show = False):
	#offset = pm.Vec2d(rnd.uniform(-5, 5), rnd.uniform(-5, 5))
	offset = pm.Vec2d(0, 0)
	#rot = rnd.uniform(0, 360)
	rot = 0
	
	moment = pm.moment_for_circle(MASS, 0, RADIUS)
	ball = pm.Body(MASS, moment)
	ballshape = pm.Circle(ball, RADIUS)
	ballshape.friction = FRICTION
	ballshape.elasticity = ELASTICITY
	ball.position = pm.Vec2d(0, 1.1 * RADIUS).rotated_degrees(rot)
	
	wall = pm.Body()
	boxverts = [v.rotated_degrees(box_rot + rot) for v in [pm.Vec2d(-100, -10), pm.Vec2d(100, -10), pm.Vec2d(100, 0), pm.Vec2d(-100, 0)]]
	wallshape = pm.Poly(wall, boxverts)
	wallshape.friction = FRICTION
	wallshape.elasticity = ELASTICITY

	mag = rnd.uniform(2, 5)
	ball_vel = pm.Vec2d(0, -mag).rotated_degrees(rnd.uniform(-45, 45) + rot)
	
	ball.position += offset
	wall.position = offset
	
	space = pm.Space()
	space.add(ball, ballshape)
	space.add_static(wallshape)
	ball.apply_impulse(ball_vel)
	
	if show:
		print('clear')
		print('s1 a ball world b {} p {} {} 0'.format(RADIUS, *ball.position))
		lower_verts = ' '.join('{} {} 0'.format(*v) for v in boxverts)
		upper_verts = ' '.join('{} {} 1'.format(*v) for v in boxverts)
		print('s1 a wall world v {}'.format(lower_verts + ' ' + upper_verts))
		
	dt = 1.0/60.0
	while True:
		if show:
			time.sleep(dt)
			print('s1 c ball p {} {} 0'.format(*ball.position))
			print(ball.position, ball.velocity, file = sys.stderr)
		
		if not show and ball.velocity != ball_vel:
			break
		
		prev_pos = ball.position
		space.step(dt)
	
	x = np.array(join_vec2(wall.position, prev_pos, ball_vel))
	y = np.array(join_vec2(ball.velocity))
	yd = np.array(join_vec2(ball.velocity - ball_vel))
	#print(x, y, yd, file = sys.stderr)
	return x, y, yd

def compare_errors(simulation, ratio_error):
	Xrows = []
	Yrows = []
	for i in range(NTRAIN):
		x, y, _ = simulation()
		#all = np.hstack((x, y))
		#print(' '.join(str(i) for i in all))
		Xrows.append(x)
		Yrows.append(y)
	
	X = np.vstack(Xrows)
	Y = np.vstack(Yrows)
	ols = la.lstsq(X, Y)
	kernels = [
		lambda d: 1,
		lambda d: 1.0 / d,
		lambda d: 1.0 / (d ** 2),
		lambda d: 1.0 / (d ** 3),
#		lambda d: 1.0 / (d ** 4),
	]
	kernel_names = ['1.0/x^{}'.format(i) for i in range(len(kernels))]
	#ks = [1,2,3,4,5,10,20,40,80,100,200]
	ks = [1,3,5,10,50,100]
	lwr = []
	lwr_error = []
	for kernel in kernels:
		same_kernel = []
		e = []
		for k in ks:
			same_kernel.append(LWR(X, Y, k, kernel))
			e.append(np.zeros((1, Y.shape[1])))
		lwr.append(same_kernel)
		lwr_error.append(e)
	
	lwr_error = [[0.0] * len(ks) for i in range(len(kernels))]
	ols_error = np.zeros((1, Y.shape[1]))
	for i in range(NTEST):
		#x = Xrows[i] + np.random.normal(0, 0.001, (1, len(Xrows[i])))
		#y = Yrows[i] + np.random.normal(0, 0.001, (1, len(Yrows[i])))
		x, y, dy = simulation()
		
		# OLS
		e = np.abs(y - np.dot(x, ols[0]))
		if ratio_error:
			e /= np.abs(dy)
		ols_error += e
		
		# LWR
		for j in range(len(kernels)):
			for k in range(len(ks)):
				e = np.abs(y - lwr[j][k].predict(x))
				if ratio_error:
					e /= np.abs(dy)
				lwr_error[j][k] += e
		
		if i % 10 == 0:
			print(i, end = ' ', file = sys.stderr)
			sys.stderr.flush()
	
	print()
	print('OLS weights:')
	print(ols[0])
	print()
	
	print('OLS error:', ols_error)
	print('LWR error:')
	for i in range(len(kernels)):
		for j in range(len(ks)):
			print('{} {:3} {}'.format(kernel_names[i], ks[j], lwr_error[i][j]))
			
	# plot a horizontal line for ordinary least squares
	plt.semilogy()
	plt.plot([ks[0], ks[-1]], [ols_error.mean() / NTEST] * 2, label = 'OLS')
	for i in range(len(kernels)):
		plt.plot(ks, [e.mean() / NTEST for e in lwr_error[i]], label = kernel_names[i])
	plt.legend(loc='upper right')
	plt.show()

if __name__ == '__main__':
	#compare_errors(two_balls, True)
	#compare_errors(two_balls_static, True)
	#compare_errors(lambda: ball_wall(0), True)
	#ball_wall(0, True)
	#two_balls(True)
	#two_balls_static(True)
	