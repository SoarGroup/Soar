from __future__ import print_function
import sys, os
import numpy as np
import pdb
import itertools as it
import random as rnd
import time
import sml_helper
sml = sml_helper.sml

rnd.seed(0)
np.random.seed(0)
NPROPS = 3

WEIGHTS = None

def combinations(elems, n, ordered, repeat):
	if not ordered and not repeat:
		return set(it.combinations(elems, n))
	
	result = set()
	for comb in it.product(*([elems] * n)):
		if not repeat and len(set(comb)) < len(comb):
			continue
		
		if not ordered:
			result.add(tuple(sorted(comb)))
		else:
			result.add(comb)
	
	return result

# no replacement
def weighted_sample(weights, n):
	assert len(weights) >= n
	sum = 0
	intervals = []
	for w in weights:
		sum += w
		intervals.append(sum)
	
	sample = set()
	while len(sample) < n:
		r = rnd.uniform(0, sum)
		for i, s in enumerate(intervals):
			if s >= r:
				sample.add(i)
	
	return sample
	
class Box:
	def __init__(self, name, pos, dims):
		self.name = name
		self.dims = dims
		self.pos = pos
		self.added = False
	
	def set_pos(self, pos):
		self.pos = pos
	
	def set_rand_pos(self, min, max):
		self.pos = np.array([rnd.uniform(min, max) for i in range(3)])
		
	def get_pos(self):
		return self.pos

	def min(self):
		return self.pos
	
	def max(self):
		return self.pos + self.dims
	
	def get_sgel(self):
		if not self.added:
			pre = 'a {} world v 0 0 0 0 0 1 0 1 0 0 1 1 1 0 0 1 0 1 1 1 0 1 1 1'.format(self.name)
			self.added = True
		else:
			pre = 'c {}'.format(self.name)
		return '{} p {}'.format(pre , ' '.join(str(p) for p in self.pos))
		
	def __str__(self):
		return self.name
	
def overlap(a, b): return (a[0] <= b[0] <= a[1]) or (b[0] <= a[0] <= b[1])

def intersects(a, b):
	aints = [ (a.pos[i], a.pos[i] + a.dims[i]) for i in range(3) ]
	bints = [ (b.pos[i], b.pos[i] + b.dims[i]) for i in range(3) ]
	return overlap(aints[0], bints[0]) and overlap(aints[1], bints[1]) and overlap(aints[2], bints[2])

def ontop(a, b):
	return intersects(a, b) and a.min()[2] == b.max()[2]

def east(a, b): return a.min()[0] >= b.max()[0]
def west(a, b): return a.max()[0] <= b.min()[0]
	
PREDICATES = {
	# name        nparams   ordered    repeat   function
	#'intersect': (2,        False,     False,   intersects),
	#'ontop':     (2,        True,      False,   ontop),
	'east':      (2,        True,      False,   east),
	'west':      (2,        True,      False,   west),
}

class Atom:
	def __init__(self, pred, args, func):
		self.pred = pred
		self.args = args
		self.func = func
	
	def decide(self):
		return self.func(*self.args)
	
	def get_args(self):
		return self.args
		
	def __str__(self):
		return '{}({})'.format(self.pred, ','.join(str(a) for a in self.args))

class Scene:
	def __init__(self, boxes):
		self.boxes = boxes
		self.box_names = dict((b.name, b) for b in self.boxes)
	
	def get_props(self):
		#y = ' '.join(b.name for b in self.boxes)
		return np.hstack(b.get_pos() for b in self.boxes)
	
	def set_props(self, props):
		assert(len(props) == 3 * len(self.boxes))
		for i, b in enumerate(self.boxes):
			b.set_pos(props[i * NPROPS : i * NPROPS + NPROPS])
	
	def get_atom(self, pred, args):
		if pred not in PREDICATES:
			return None
		nparams, ordered, repeat, func = PREDICATES[pred]
		if len(args) != nparams:
			return None
		if not repeat and len(set(args)) != len(args):
			return None
		
		bargs = [ self.box_names.get(a, None) for a in args ]
		if not all(bargs):
			return None
		
		return Atom(pred, bargs, func)
		
	def get_atoms(self):
		atoms = []
		for pred in PREDICATES:
			nparams, ordered, repeat, func = PREDICATES[pred]
			for c in combinations(self.boxes, nparams, ordered, repeat):
				atoms.append(Atom(pred, c, func))
		return atoms
	
	def get_ndims(self):
		return len(self.boxes) * 3
	
	def get_sgel(self):
		s = '\n'.join(b.get_sgel() for b in self.boxes)
		return s
	
	def get_dim_name(self, i):
		nbox = int(i / NPROPS)
		prop = ['px', 'py', 'pz'][i % NPROPS]
		return self.boxes[nbox].name + ':' + prop
	
	def readd(self):
		for b in self.boxes:
			b.added = False

class LinearMode:
	def __init__(self, weights):
		self.weights = weights
	
	def calc(self, x):
		assert len(x) == len(self.weights)
		return np.dot(x, self.weights)
	
	def __str__(self):
		return ' '.join(str(w) for w in self.weights)

class DTree:
	def __init__(self, parent, test, split = None, mode = None, left = None, right = None):
		self.parent = parent
		self.test = test
		self.split = split
		self.mode = mode
		self.left = left
		self.right = right
	
	def set_children(self, left = None, right = None):
		self.left = left
		self.right = right
		
	def decide(self):
		if not self.split:
			return self.mode
		
		if self.split.decide():
			return self.left.decide()
		return self.right.decide()
	
	def get_conditions(self):
		if self.parent == None:
			return [], []
		
		pos, neg = self.parent.get_conditions()
		if self.test:
			pos.append(self.parent.split)
		else:
			neg.append(self.parent.split)
		return pos, neg
	
	def get_leaves(self):
		if self.mode != None:
			return [self]
		leaves = self.left.get_leaves()
		leaves.extend(self.right.get_leaves())
		return leaves
	
	def graphviz(self):
		if self.mode != None:
			return '{} [label="linear"];'.format(id(self))
		else:
			s = '{0} [label="{1}"]; {0} -> {2}; {0} -> {3};'.format(id(self), str(self.split), id(self.left), id(self.right))
			l = self.left.graphviz()
			r = self.right.graphviz()
			return '\n'.join([s, l, r])
		
	def __str__(self):
		if self.parent:
			if self.test:
				p = str(self.parent) + '=1:'
			else:
				p = str(self.parent) + '=0:'
		else:
			p = ''
		if self.mode != None:
			p += str(self.mode)
		else:
			p += str(self.split)
		
		return p
	
	def print_tree(self):
		if self.mode != None:
			return str(self)
		return self.left.print_tree() + '\n' + self.right.print_tree()

prop_log = open('props.txt', 'w')

class Env:
	def __init__(self, trees, scene, agent):
		self.trees = trees
		self.scene = scene
		self.agent = agent
		assert len(self.trees) == self.scene.get_ndims()
	
	def run(self):
		output = self.agent.GetSVSOutput() # throw it away for now
		curr = self.scene.get_props()
		next = curr
		for i in range(len(next)):
			mode = self.trees[i].decide()				
			if mode != None:
				next[i] = mode.calc(curr)
		
		self.scene.set_props(next)
		
		ident = id(self.trees[0].decide())
		h = hash(tuple(self.trees[0].decide().weights))
		print('{} {} {}'.format(ident, h, ' '.join(str(x) for x in next)), file = prop_log)
		self.agent.SendSVSInput(self.scene.get_sgel())

# should modify this to choose atoms involving the target object with higher probability
def choose_atom(atoms, used_atoms):
	return rnd.randint(0, len(atoms) - 1)

# Desirable properties for coefficients of linear functions
# 
# - property values should not change dramatically between time steps - at the most, say 5%
# 
# - most likely, the value being predicted will depend on its previous value, so its dimension should get a significant coefficient
# 
# - it's unlikely that an object will be affected by every other object - the coefficients should be sparse
# 
# - it's more likely that an object is affected by objects it interacts with
# 
# - some object types may affect all other objects identically, for example if the object had magnetism
#
# - different functions should be significantly different
# 
# based on the above ...
# 
#   assign coefficient 1 to target dimension
# 
#   choose a total number of objects N that can affect the target value. this should follow a poisson distribution, or be a hard limit
# 
#   assign a probability that every other object affects this value. objects that are interacting with target object have higher probability
# 
#   choose the N objects based on the differing object probabilities, all other coefficents are 0
# 
#   assign coefficients randomly to these chosen objects. individual coefficients should not exceed, say, +-0.01, and the sum should not exceed +-0.05
def gen_coefs(index, objs, atoms):
	MAXOBJS = 4
	coefs = np.zeros(len(objs) * NPROPS)
	
	interacting_objs = set()
	for a in atoms:
		interacting_objs.update(a.get_args())
	
	weights = []
	for o in objs:
		if o in interacting_objs:
			weights.append(5)
		else:
			weights.append(1)
	
	inds = weighted_sample(weights, min(len(objs), MAXOBJS))
	for i in inds:
		coefs[i * NPROPS : i * NPROPS + NPROPS] = np.random.rand(NPROPS) - .5
	
	coefs /= np.absolute(coefs).max()
	coefs *= 0.05
	coefs[index] = 1
	return coefs

def gen_tree(index, objs, atoms, k, max_depth, depth = 1, used_atoms = [], parent = None, test = False):
	if len(atoms) > 0 and depth < max_depth and rnd.uniform(0, 1) < (1 / ((depth + 1) ** k)):
		i = choose_atom(atoms, used_atoms)
		atoms_copy = atoms[:]
		a = atoms_copy.pop(i)
		used_copy = used_atoms + [a]
		t = DTree(parent, test, a)
		t.left = gen_tree(index, objs, atoms_copy, k, max_depth, depth + 1, used_copy, t, True)
		t.right = gen_tree(index, objs, atoms_copy, k, max_depth, depth + 1, used_copy, t, False)
		return t
	else:
		c = gen_coefs(index, objs, used_atoms)
		mode_func = LinearMode(c)
		return DTree(parent, test, None, mode_func)

def randomize_until(scn, pos, neg):
	ndims = scn.get_ndims()
	while True:
		if all(p.decide() for p in pos) and not any(n.decide() for n in neg):
			return True
		scn.set_props([rnd.uniform(0, 100) for i in range(ndims)])
	
def output_handler(id, env, agent, phase):
	env.run()

def reinit_handler(id, env, agent):
	print('got agent reinit')
	env.scene.readd()

if __name__ == '__main__':
	cli = sml_helper.cli()
	kernel = cli.kernel
	agent = cli.agent

	NBOXES = 2
	boxes = [Box('b{}'.format(i), np.array([0,0,0]), np.array([1,1,1])) for i in range(NBOXES)]
	for b in boxes:
		b.set_rand_pos(-100, 100)
	
	scene = Scene(boxes)
	
	atoms = scene.get_atoms()
	dims = scene.get_ndims()
	trees = []
	for i in range(dims):
		trees.append(gen_tree(i, boxes, atoms, 0.001, 2))
	
	model_log = open('models.txt', 'w')
	for i in range(dims):
		print(scene.get_dim_name(i), file=model_log)
		print(trees[i].print_tree(), file=model_log)
	model_log.close()

	e = Env(trees, scene, agent)
	agent.RegisterForRunEvent(sml.smlEVENT_AFTER_OUTPUT_PHASE, output_handler, e, True)
	kernel.RegisterForAgentEvent(sml.smlEVENT_AFTER_AGENT_REINITIALIZED, reinit_handler, e, True)
	cli.execute('source agent.soar')
	cli.execute('waitsnc -e')
	
	leaves = trees[0].get_leaves()
	for l in leaves:
		print('----', file = prop_log)
		WEIGHTS = np.copy(l.mode.weights)
		pos, neg = l.get_conditions()
		randomize_until(scene, pos, neg)
		if trees[0].decide() != l.mode:
			import pdb; pdb.set_trace()
		print(id(l.mode))
		scene.readd()
		cli.execute('init')
		cli.execute('svs 0 learn_model 1')
		cli.execute('run 80')
		cli.run()
