from __future__ import print_function
import sys, os
import sml

times = 0
pos = 2

def output_handler(id, world, agent, phase):
	global times
	global pos
	
	if times == 0:
		agent.SendSVSInput("a b1 world p {} 0 0 b 1\n".format(pos))
	else:
		pos = pos ** 1.1
		agent.SendSVSInput("c b1 p {} 0 0\n".format(pos))
	times += 1
	
if __name__ == '__main__':
	cli = sml.cli()
	cli.agent.RegisterForRunEvent(sml.sml.smlEVENT_AFTER_OUTPUT_PHASE, output_handler, None)
	cli.execute('source agent.soar')
	cli.repl()
