from __future__ import print_function
import sys, os
import random
import sml

MINPOS = 0
MAXPOS = 50
BLOCKSIZE = 10

def block_verts(h, w, d):
	h2 = h / 2
	w2 = w / 2
	d2 = d / 2
	
	return [ -h2, -w2, -d2,
	          h2, -w2, -d2,
	          h2,  w2, -d2,
	         -h2,  w2, -d2,
	         -h2, -w2,  d2,
	          h2, -w2,  d2,
	          h2,  w2,  d2,
	         -h2,  w2,  d2 ]

def overlap(a1, a2, b1, b2):
	return a1 <= b1 < a2 or b1 <= a1 < b2

def dist(p1, p2):
	return sum((x1 - x2) ** 2 for x1, x2 in zip(p1, p2))

def check_bounds(a, b):
	return MINPOS <= a <= b <= MAXPOS

class Block:
	def __init__(self, name):
		self.name = name
		self.added = False;
		self.verts = block_verts(BLOCKSIZE, BLOCKSIZE, BLOCKSIZE)
		self.dims = (BLOCKSIZE, BLOCKSIZE, BLOCKSIZE)
		self.pos = [0.0, 0.0, 0.0]
		self.dirty = True
	
	def get_sgel(self):
		if not self.dirty:
			return ""
		
		if not self.added:
			sgel = "a {} world v {} ".format(self.name, ' '.join(str(x) for x in self.verts))
			self.added = True
		else:
			sgel = "c {} ".format(self.name)
		
		sgel += "p {}".format(' '.join(str(x) for x in self.pos))
		self.dirty = False
		return sgel
	
	def move(self, offsets):
		for i in range(3):
			self.pos[i] += offsets[i]
		self.dirty = True
	
	def move_to(self, pos):
		self.pos = pos
		self.dirty = True

	def min(self):
		return [ self.pos[i] - self.dims[i] / 2 for i in range(3) ]
	
	def max(self):
		return [ self.pos[i] + self.dims[i] / 2 for i in range(3) ]
		
	def intersects(self, b):
		amin = self.min()
		amax = self.max()
		bmin = b.min()
		bmax = b.max()
		for i in range(3):
			if not overlap(amin[i], amax[i], bmin[i], bmax[i]):
				return False
		return True
		
class World:
	def __init__(self, cursor, blocks):
		self.cursor = cursor
		self.blocks = blocks
		self.time = 0
	
	def get_sgel(self):
		sgel = ""
		sgel += self.cursor.get_sgel()
		for c in self.blocks:
			sgel += "\n" + c.get_sgel()
		return sgel
	
	def input(self, d):
		self.time += 1
		self.cursor.move(d)
		for b in self.blocks:
			if self.cursor.intersects(b):
				# There are six possible positions for the block that resolve the collision,
				# 2 for each dimension. Move it to the closest one.
				positions = []
				for i in range(3):
					p1 = b.pos[:]; p2 = b.pos[:]
					p1[i] = self.cursor.pos[i] - self.cursor.dims[i] / 2 - b.dims[i] / 2
					p2[i] = self.cursor.pos[i] + self.cursor.dims[i] / 2 + b.dims[i] / 2
					positions.append(p1)
					positions.append(p2)
				
				dists = [ dist(b.pos, p) for p in positions ]
				closest = min(zip(dists, positions))[1]
				dpos = [x1 - x2 for x1, x2 in zip(closest, b.pos)]
				b.move(dpos)
				#assert not self.cursor.intersects(b)

def update(world):
	if world.time == 35:
		c = world.cursor
		b = world.blocks[0]
		c.move_to([b.pos[0] - BLOCKSIZE + 1, b.pos[1] + BLOCKSIZE, b.pos[2]])
	world.input((1, 0, 0))
	
def output_handler(id, world, agent, phase):
	update(world)
	sgel = world.get_sgel()
	agent.SendSVSInput(sgel)
	
if __name__ == '__main__':
	random.seed(1)
	
	args = [2, 1, 'l']
	
	b1 = Block("b1")
	b2 = Block("b2")
	b3 = Block("b3")
	
	b2.move_to([25, 0, 0])
	b3.move_to([25, -BLOCKSIZE, 0])
	w = World(b1, [b2, b3])
	
	if False:
		for i in range(40):
			update(w)
		
		sys.exit(0)
	
	cli = sml.cli()
	cli.agent.RegisterForRunEvent(sml.sml.smlEVENT_AFTER_OUTPUT_PHASE, output_handler, w)
	cli.execute('source agent.soar')
	#cli.execute('svs 0 learn_models off')
	#cli.execute('run 3')
	#cli.execute('svs model b2x load')
	#cli.execute('svs 0 test_models on')
	cli.repl()
	