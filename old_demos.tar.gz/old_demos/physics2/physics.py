from __future__ import print_function
import itertools as it
import ode
import random
import subprocess as proc

STATIC_CATEGORY  = 1
DYNAMIC_CATEGORY = 2
STATIC_COLLIDE   = 2  # static only collides with dynamic (don't collide static with static)
DYNAMIC_COLLIDE  = 3  # dynamic collides with everything

STEP_SIZE = 1/1000.0
ERP = 1.0
CFM = 0  # 10e-10
GRAVITY = (0, 0, -980)  # 900 = default
BOUNCE = 0.5
MU = 0.0

BOX_TRIS = [
	(0,2,6),
	(0,6,4),
	(0,4,5),
	(0,5,1),
	(4,6,5),
	(7,5,6),
	(0,3,2),
	(0,1,3),
	(2,3,6),
	(7,6,3),
	(1,5,3),
	(7,3,5),
]

def eq(a, b):
	if a == b:
		return True
	elif a < b:
		return b - a < 1.0e-6
	else:
		return a - b < 1.0e-6

def round_down(x):
	return 0.0 if abs(x) < 1.0e-10 else x

def is_box(verts):
	if len(verts) != 8:
		return None, None
	
	s = sorted(verts)
	x1, y1, z1 = s[0]; x2, y2, z2 = s[-1]  # extreme corners

	for i in range(8):
		if (i < 4 and s[i][0] != x1) or (i >= 4 and s[i][0] != x2):
			return None, None
		if (i in (0, 1, 4, 5) and not eq(s[i][1], y1)) or \
		   (i in (2, 3, 6, 7) and not eq(s[i][1], y2)):
			return None, None
		if (i in (0, 2, 4, 6) and not eq(s[i][2], z1)) or \
		   (i in (1, 3, 5, 7) and s[i][2] != z2):
			return None, None
	
	return (x2 - x1, y2 - y1, z2 - z1), ((x2 + x1) / 2, (y2 + y1) / 2, (z2 + z1) / 2)

def convex_hull(verts):
	dims = len(verts[0])
	n = len(verts)
	
	vertlines = ['{} {} {}'.format(*v) for v in verts]
	input = '{}\n{}\n{}'.format(dims, n, '\n'.join(vertlines))
	qhull = proc.Popen("qconvex i Qt".split(), stdin=proc.PIPE, stdout=proc.PIPE, stderr=proc.PIPE)
	out, err = qhull.communicate(input)
	if qhull.wait() != 0:
		print(err)
		print('qconvex exited with non-zero status')
		sys.exit(1)
	
	lines = filter(None, out.split('\n'))
	triangles = []
	ntris = int(lines[0])
	for line in lines[1:]:
		# qconvex seems to return triangles in clockwise order, so reverse it
		triangles.append(tuple(reversed([int(x) for x in line.split()])))
	
	assert(len(triangles) == ntris)
	return triangles

def collision_handler(args, geom1, geom2):
	world, contactgroup = args
	contacts = ode.collide(geom1, geom2)
	for c in contacts:
		pos, norm, depth, g1, g2 = c.getContactGeomParams()
		#print ('pos: {}  norm: {}  depth: {}'.format(pos, norm, depth))
		#e1 = geom1.owner.elasticity
		#e2 = geom2.owner.elasticity
		#f1 = geom1.owner.friction
		#f2 = geom2.owner.friction
		#c.setBounce(min(e1,e2))
		#c.setMu(f1 + f2)
		c.setBounce(BOUNCE)
		c.setMu(MU)
		print (c.getMode(), c.getBounce(), c.getBounceVel(), c.getSoftCFM(), c.getSoftERP())
		j = ode.ContactJoint(world, contactgroup, c)
		j.attach(geom1.getBody(), geom2.getBody())

def ftos(x):
	return x.hex()

class Obj:
	def init(self, world, space, name, type, geom, mass, elas = 1.0, fric = 0.0):
		self.added = False
		self.name = name
		self.type = type
		self.world = world
		self.space = space
		self.elasticity = elas
		self.friction = fric
		self.geom = geom
		self.geom.owner = self
		if not mass:
			self.body = None
			self.geom.setCategoryBits(STATIC_CATEGORY)
			self.geom.setCollideBits(STATIC_COLLIDE)
		else:
			self.body = ode.Body(self.world)
			self.body.setMass(mass)
			self.geom.setBody(self.body)
			self.geom.setCategoryBits(DYNAMIC_CATEGORY)
			self.geom.setCollideBits(DYNAMIC_COLLIDE)

	def set_pos(self, p):
		self.geom.setPosition(p)

	def get_pos(self):
		return self.geom.getPosition()
	
	def set_vel(self, v):
		assert(self.body)
		self.body.setLinearVel(v)
	
	def get_vel(self):
		if self.body:
			return tuple( round_down(v) for v in self.body.getLinearVel() )
			
		return None
	
	def get_sgel(self):
		if self.body == None and self.added:
			return ''
		
		if not self.added:
			if hasattr(self, 'radius'):
				shape_str = 'b {}'.format(ftos(self.radius))
			else:
				assert(hasattr(self, 'verts') and hasattr(self, 'triangles'))
				shape_str = 'v ' + ' '.join('{} {} {}'.format(*v) for v in self.verts)
				shape_str += ' i'
				for t in self.triangles:
					shape_str += ' ' + ' '.join(str(x) for x in t)
			
			sgel = "a {} {} world {}".format(self.name, self.type, shape_str)
			self.added = True
		else:
			sgel = "c " + self.name
		
		sgel += " p {} {} {}".format(*(ftos(x) for x in self.geom.getPosition()))
		
		return sgel
		
class Ball(Obj):
	def __init__(self, world, space, name, type, radius, mass, elas=1.0, fric=0.0):
		assert(mass != None)
		
		self.radius = radius
		g = ode.GeomSphere(space, radius)
		m = ode.Mass()
		m.setSphereTotal(mass, radius)
		self.init(world, space, name, type, g, m, elas, fric)
		
class Box(Obj):
	def __init__(self, world, space, name, type, dims, mass, elas=1.0, fric=0.0):
		g = ode.GeomBox(space, dims)
		if mass == None:
			m = None
		else:
			lx, ly, lz = dims
			m = ode.Mass()
			m.setBoxTotal(mass, lx, ly, lz)

		self.init(world, space, name, type, g, m, elas)
		
		#self.shape.elasticity = elas
		#self.shape.owner = self
		
		x1, x2, y1, y2, z1, z2 = self.geom.getAABB()
		self.verts = it.product((x1,x2),(y1,y2),(z1,z2))
		self.triangles = BOX_TRIS

class Convex(Obj):
	def __init__(self, world, space, name, type, verts, triangles, elas=1.0, fric=0.0):
		# triangulate each plane
		self.triangles = triangles
		if self.triangles == None:
			self.triangles = convex_hull(verts)

		trimesh = ode.TriMeshData()
		trimesh.build(verts, self.triangles)
		g = ode.GeomTriMesh(trimesh, space)
		self.init(world, space, name, type, g, None, elas, fric)
		self.verts = verts

class Environment:
	def __init__(self):
		self.objs = []
		self.world = ode.World()
		self.world.setGravity(GRAVITY)
		self.world.setERP(ERP)
		self.world.setCFM(CFM)
		self.space = ode.Space(1)
		self.group = ode.JointGroup()

	def add(self, obj, pos = None, vel = None):
		self.objs.append(obj)
		if pos != None:
			obj.set_pos(pos)
		if vel != None:
			obj.set_vel(vel)
	
#	# In an ODE simulation step, object velocities are first updated based on
#	# forces, then positions are updated based on the new velocities. Therefore
#	# the velocity reported for an object with getLinearVel is always the velocity
#	# of the last time step, which is not useful for prediction. To correct this,
#	# I cache an SGEL string that reports the positions from the previous time
#	# step with the velocities from the current time step.
#	def step(self):
#		self.sgel = '\n'.join(o.get_sgel() for o in self.objs)
#		self.space.collide((self.world, self.group), collision_handler)
#		self.world.step(STEP_SIZE)
#		self.group.empty()
#		
#		for o in self.objs:
#			v = o.get_vel()
#			if v:
#				s = '\n'.join(['p {} vx {}'.format(o.name, ftos(v[0])),
#				               'p {} vy {}'.format(o.name, ftos(v[1])),
#				               'p {} vz {}'.format(o.name, ftos(v[2]))])
#				self.sgel += '\n' + s
#
# EDIT: This previous approach made it impossible to predict when velocities
# will change due to collisions, because at the first point of intersection,
# the object's velocity is already updated to post collision value, so I can't
# predict a velocity flip based on intersection.

	def step(self):
		old_pos = {}
		for o in self.objs:
			if o.body:
				old_pos[o] = o.get_pos()
		
		self.space.collide((self.world, self.group), collision_handler)
		self.world.step(STEP_SIZE)
		self.group.empty()
		
		self.sgel = '\n'.join(o.get_sgel() for o in self.objs)
		for o in self.objs:
			if o.body:
				p1 = old_pos[o]
				p2 = o.get_pos()
				print('velocity = ', o.body.getLinearVel()[0])
				s = '\n'.join(['p {} vx {}'.format(o.name, ftos(round_down(p2[0] - p1[0]))),
				               'p {} vy {}'.format(o.name, ftos(round_down(p2[1] - p1[1]))),
				               'p {} vz {}'.format(o.name, ftos(round_down(p2[2] - p1[2])))])
				self.sgel += '\n' + s

	def get_sgel(self):
		return self.sgel

	def random_offset(self, amount):
		offset = tuple(random.uniform(-amount, amount) for i in range(3))
		for o in self.objs:
			p = o.geom.getPosition()
			np = tuple(p[i] + offset[i] for i in range(3))
			o.geom.setPosition(np)

	def read_blender_dump(self, path):
		input = open(path)
		assert(input)
		
		while True:
			ns = input.readline()
			ts = input.readline()
			ms = input.readline()
			ps = input.readline()
			rs = input.readline()
			ss = input.readline()
			es = input.readline()
			fs = input.readline()
			if not all((ns, ps, rs, ss, es, fs)):
				break
			
			name = ns.strip()
			type = ts.strip()
			mass = float(ms.strip())
			if mass == 0.0:
				mass = None
			pos = tuple(float(s) for s in ps.split())
			rot = tuple(float(s) for s in rs.split())
			scale = tuple(float(s) for s in ss.split())
			elas = float(es)
			fric = float(fs)

			if type.startswith('ball'):
				rs = input.readline()
				vs = input.readline()
				radius = float(rs)
				vel = [float(s) for s in vs.split()]
				obj = Ball(self.world, self.space, name, type, radius, mass, elas, fric)
				self.add(obj, pos, vel)
				assert(input.readline().strip() == '.')
			else:
				verts = []
				faces = []
				while True:
					l = input.readline()
					assert(l)
					if l.strip() == '.':
						break
					verts.append(tuple(float(s) for s in l.split()))
				
				while True:
					l = input.readline()
					assert(l)
					if l.strip() == '.':
						break
					f = tuple(int(s) for s in l.split())
					assert(len(f) >= 3)
					for v in f:
						assert(0 <= v < len(verts))
					faces.append(f)

				assert(len(verts) > 0 and len(faces) > 0)
				box_dims, offset = is_box(verts)
				if box_dims == None:
					print('{} is a trimesh'.format(name))
					obj = Convex(self.world, self.space, name, type, verts, faces, elas, fric)
				else:
					print('{} is a box'.format(name))
					obj = Box(self.world, self.space, name, type, box_dims, None, elas, fric)
					pos = tuple(pos[i] + offset[i] for i in range(3))
				
				self.add(obj, pos)
