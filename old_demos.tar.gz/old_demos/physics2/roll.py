#!/usr/bin/env python

from __future__ import print_function
import sys, os
import random
from physics import *
import sml

GRAVITY = (0, 0, -980)

BALLR = 1
BALL_MASS = 1.0

BALL_POS = (0, 0, 20)
BALL_VEL = (1, 0, 0)

def output_handler(id, env, agent, phase):
	env.step()
	sgel = env.get_sgel()
	agent.SendSVSInput(sgel)
	
class Experiment:
	def __init__(self):
		self.cli = sml.cli()
		self.agent = self.cli.agent
		self.kernel = self.cli.kernel
		
		self.cli.execute('waitsnc -e')
		self.output_event = None
	
	def reset(self):
		if self.output_event != None:
			self.agent.UnregisterForRunEvent(self.output_event)
		
		self.env = Environment(GRAVITY)
		world = self.env.world
		space = self.env.space

		verts = [(-50, 5, 5), (-50, -5, 5), (50, 5, 5), (50, -5, 5),
		         (-50, 5, -5), (-50, -5, -5), (50, 5, -5), (50, -5, -5)]
		faces = [(1, 2, 0), (1, 3, 2), # top
		         (5, 6, 4), (5, 7, 6), # bottom
		         (5, 3, 1), (5, 7, 3), # front
		         (0, 4, 6), (0, 6, 2), # back
		         (0, 4, 5), (0, 5, 1), # left
		         (2, 6, 7), (2, 7, 3), # right
		        ]

		#ground = Box(world, space, 'g', (100, 10, 10), None, 0.001, 0)
		ground = Convex(world, space, 'g', verts, faces, 0.001, 0)
		
		self.env.add(ground)
		ball = Ball(world, space, 'b1', BALLR, BALL_MASS, 0.001, 0)
		self.env.add(ball, BALL_POS, BALL_VEL)
		
		# Need to do this first step so that all velocities
		# have real values the first time Soar sees them
		self.env.step()
		init_input = self.env.get_sgel()
		self.agent.SendSVSInput(init_input)
		self.output_event = self.agent.RegisterForRunEvent(sml.sml.smlEVENT_AFTER_OUTPUT_PHASE, output_handler, self.env)
	
	def run(self):
		self.reset()
		self.cli.execute('svs learn on')
		self.cli.execute('svs 0 learn_models on')
		self.cli.repl()

if __name__ == '__main__':
	exp = Experiment()
	exp.run()
	