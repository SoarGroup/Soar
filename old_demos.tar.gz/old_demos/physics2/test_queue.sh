#!/bin/bash

. queue.sh

make_queue queue_dir 2 || exit 1

for i in `seq 5`
do
	(init_job this is job $i
	for j in `seq 5`
	do
		echo $i running
		sleep 1
	done
	echo $i is done) &
	reg_queue
done

wait_queue
