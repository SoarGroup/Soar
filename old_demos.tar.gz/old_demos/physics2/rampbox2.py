# temporary environment to test different numbers of objects between training and testing

from __future__ import print_function
import sys, os
import random
import physics2 as physics
import agent

BALL_RADIUS = .25
BALL_MASS = 1
BALL_VEL = 40

RAMP_LENGTH = 4
RAMP_HEIGHT = 2

BOX_SIZE = 2
BOX_HSIZE = BOX_SIZE / 2
BOX_DIMS = [BOX_SIZE] * 3

MIN_SEP = 1
MAX_SEP = 2

RAMP_VERTS = [
	(0,           -1, 0          ), (0,           1, 0          ),
	(0,           -1, RAMP_HEIGHT), (0,           1, RAMP_HEIGHT),
	(RAMP_LENGTH, -1, 0          ), (RAMP_LENGTH, 1, 0          ) ]

ROOM_SIZE = 30
MIN_LEFT = 1
MAX_LEFT = 2

RAND_SEED = 0

def generate_env():
	global RAND_SEED
	
	env = physics.Environment()
	
	suf = str(RAND_SEED)
	ball = physics.Ball(env.world, env.space, 'b1', 'ball', BALL_RADIUS, BALL_MASS, 0, 0)
	ramp1 = physics.Convex(env.world, env.space, 'ramp1' + suf, 'ramp', RAMP_VERTS, None, 0, 0)
	ramp2 = physics.Convex(env.world, env.space, 'ramp2' + suf, 'ramp', RAMP_VERTS, None, 0, 0)
	box1 = physics.Box(env.world, env.space, 'box1' + suf, 'box', BOX_DIMS, None, 0, 0)
	box2 = physics.Box(env.world, env.space, 'box2' + suf, 'box', BOX_DIMS, None, 0, 0)
	
	lw = physics.Box(env.world, env.space, 'lw' + suf, 'wall', (2, 2, ROOM_SIZE), None, 0, 0)
	rw = physics.Box(env.world, env.space, 'rw' + suf, 'wall', (2, 2, ROOM_SIZE), None, 0, 0)
	ceil = physics.Box(env.world, env.space, 'ceil1' + suf, 'ceiling', (ROOM_SIZE, 2, 2), None, 0, 0)
	floor = physics.Box(env.world, env.space, 'floor1' + suf, 'floor', (ROOM_SIZE, 2, 2), None, 0, 0)
	
	env.add(lw, (-1, 0, ROOM_SIZE / 2))
	env.add(rw, (ROOM_SIZE + 1, 0, ROOM_SIZE / 2))
	env.add(floor, (ROOM_SIZE / 2, 0, -1))
	env.add(ceil, (ROOM_SIZE / 2, 0, ROOM_SIZE + 1))
	
	env.add(ramp1, (5, 0, 0))
	env.add(ramp2, (10, 0, 0))
	env.add(box1, (15, 0, BOX_HSIZE))
	env.add(box2, (20, 0, BOX_HSIZE))
	
	env.add(ball, (10, 0, 10), (-BALL_VEL, 0, 0))
	return env
	
if __name__ == '__main__':
	if len(sys.argv) < 2:
		print('usage: {} <model>'.format(sys.argv[0]))
		sys.exit(1)
	
	model = sys.argv[1]

	env = generate_env()
	a = agent.Agent(env, [model], False)
	a.run()
