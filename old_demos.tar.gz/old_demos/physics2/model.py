#!/usr/bin/env python

from __future__ import print_function
import sys, os
import random
import physics
import agent

if __name__ == '__main__':
	if len(sys.argv) < 2:
		print('specify a model', file=sys.stderr)
		sys.exit(1)
	
	model = 'models/' + sys.argv[1] + '.model'
	if not os.path.exists(model):
		print('model does not exist', file=sys.stderr)
		sys.exit(1)
	
	test = False
	if len(sys.argv) > 2:
		test = (sys.argv[2] == 'test')
		
	env = physics.Environment()
	env.read_blender_dump(model)
	
	a = agent.Agent(env, ['b1:vx'], test)
	a.run()
	