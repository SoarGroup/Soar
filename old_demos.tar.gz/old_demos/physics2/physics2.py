from __future__ import print_function
import itertools as it
import pymunk as pm
import random
import subprocess as proc
import pdb

STEP_SIZE = 1/1000.0
GRAVITY = (0.0, -980.0)  # 900 = default
BOUNCE = 0.9
MU = 0.0

BOX_TRIS = [
	(0,2,6),
	(0,6,4),
	(0,4,5),
	(0,5,1),
	(4,6,5),
	(7,5,6),
	(0,3,2),
	(0,1,3),
	(2,3,6),
	(7,6,3),
	(1,5,3),
	(7,3,5),
]

def eq(a, b):
	if a == b:
		return True
	elif a < b:
		return b - a < 1.0e-6
	else:
		return a - b < 1.0e-6

def round_down(x):
	return 0.0 if abs(x) < 1.0e-10 else x

def ftos(x):
	return x.hex()

def convex_hull(verts):
	dims = len(verts[0])
	n = len(verts)
	
	vertlines = ['{0} {1} {2}'.format(*v) for v in verts]
	input = '{0}\n{1}\n{2}'.format(dims, n, '\n'.join(vertlines))
	qhull = proc.Popen("qconvex i Qt".split(), stdin=proc.PIPE, stdout=proc.PIPE, stderr=proc.PIPE)
	out, err = qhull.communicate(input)
	if qhull.wait() != 0:
		print(err)
		print('qconvex exited with non-zero status')
		sys.exit(1)
	
	lines = filter(None, out.split('\n'))
	triangles = []
	ntris = int(lines[0])
	for line in lines[1:]:
		# qconvex seems to return triangles in clockwise order, so reverse it
		triangles.append(tuple(reversed([int(x) for x in line.split()])))
	
	assert(len(triangles) == ntris)
	return triangles

class Obj:
	def init(self, world, space, name, type, shape, body, elas = 1.0, fric = 0.0):
		self.added = False
		self.name = name
		self.type = type
		self.space = space
		self.elasticity = elas
		self.friction = fric
		self.shape = shape
		self.body = body
		if self.body.is_static:
			self.static = True
			self.space.add(self.shape)
		else:
			self.static = False
			self.space.add(self.body, self.shape)
		
		self.shape.elasticity = BOUNCE
		self.shape.friction = MU
		
	def set_pos(self, p):
		self.body.position = (p[0], p[2])
		if self.static:
			self.space.reindex_shape(self.shape)

	def get_pos(self):
		p = self.body.position
		return (p[0], 0.0, p[1])
	
	def set_vel(self, v):
		self.body.velocity = (v[0], v[2])
	
	def get_vel(self):
		v = self.body.velocity
		return (v[0], 0.0, v[1])
	
	def get_sgel(self):
		if self.body == None and self.added:
			return ''
		
		if not self.added:
			if hasattr(self, 'radius'):
				shape_str = 'b {0}'.format(ftos(self.radius))
			else:
				assert(hasattr(self, 'verts') and hasattr(self, 'triangles'))
				shape_str = 'v ' + ' '.join('{0} {1} {2}'.format(*v) for v in self.verts)
				shape_str += ' i'
				for t in self.triangles:
					shape_str += ' ' + ' '.join(str(x) for x in t)
			
			sgel = "a {0} {1} world {2}".format(self.name, self.type, shape_str)
			self.added = True
		else:
			sgel = "c " + self.name
		
		sgel += " p {0} {1} {2}".format(*(ftos(x) for x in self.get_pos()))
		
		return sgel
		
class Ball(Obj):
	def __init__(self, world, space, name, type, radius, mass, elas=1.0, fric=0.0):
		assert(mass != None)
		
		self.radius = radius
		moment = pm.moment_for_circle(mass, 0, radius)
		body = pm.Body(mass, moment);
		shape = pm.Circle(body, radius)
		self.init(world, space, name, type, shape, body, elas, fric)
		
class Box(Obj):
	def __init__(self, world, space, name, type, dims, mass, elas=1.0, fric=0.0):
		if mass == None:
			body = pm.Body()
		else:
			moment = pm.moment_for_box(mass, dims[0], dims[2])
			body = pm.Body(mass, moment)
		
		shape = pm.Poly.create_box(body, size = (dims[0], dims[2]))
		self.init(world, space, name, type, shape, body, elas)
		
		x1, x2 = -(dims[0] / 2.0), (dims[0] / 2.0)
		y1, y2 = -(dims[1] / 2.0), (dims[1] / 2.0)
		z1, z2 = -(dims[2] / 2.0), (dims[2] / 2.0)
		self.verts = it.product((x1,x2),(y1,y2),(z1,z2))
		self.triangles = BOX_TRIS

class Convex(Obj):
	def __init__(self, world, space, name, type, verts, triangles, elas=1.0, fric=0.0):
		if triangles == None:
			self.triangles = convex_hull(verts)
		else:
			self.triangles = triangles
		self.verts = verts

		d2_verts = list(set((v[0], v[2]) for v in verts))
		body = pm.Body()
		shape = pm.Poly(body, d2_verts)
		self.init(world, space, name, type, shape, body, elas, fric)

class Environment:
	def __init__(self):
		self.objs = []
		self.world = None
		self.space = pm.Space()
		self.space.gravity = GRAVITY

	def add(self, obj, pos = None, vel = None):
		self.objs.append(obj)
		if pos != None:
			obj.set_pos(pos)
		if vel != None:
			obj.set_vel(vel)
	
	def step(self):
		old_pos = {}
		for o in self.objs:
			if not o.static:
				old_pos[o] = o.get_pos()
		
		self.space.step(STEP_SIZE)
		
		self.sgel = '\n'.join(o.get_sgel() for o in self.objs)
		for o in self.objs:
			if not o.static:
				p1 = old_pos[o]
				p2 = o.get_pos()
				#print('velocity = ', o.get_vel(), 'pos = ', p2)
				s = '\n'.join(['p {0} vx {1}'.format(o.name, ftos(round_down(p2[0] - p1[0]))),
				               'p {0} vy {1}'.format(o.name, ftos(round_down(p2[1] - p1[1]))),
				               'p {0} vz {1}'.format(o.name, ftos(round_down(p2[2] - p1[2])))])
				self.sgel += '\n' + s

	def get_sgel(self):
		return self.sgel

	def random_offset(self, amount):
		offset = tuple(random.uniform(-amount, amount) for i in range(3))
		for o in self.objs:
			p = o.get_pos()
			np = tuple(p[i] + offset[i] for i in range(3))
			o.set_pos(np)

	def read_blender_dump(self, path):
		input = open(path)
		assert(input)
		
		while True:
			ns = input.readline()
			ts = input.readline()
			ms = input.readline()
			ps = input.readline()
			rs = input.readline()
			ss = input.readline()
			es = input.readline()
			fs = input.readline()
			if not all((ns, ps, rs, ss, es, fs)):
				break
			
			name = ns.strip()
			type = ts.strip()
			mass = float(ms.strip())
			if mass == 0.0:
				mass = None
			pos = tuple(float(s) for s in ps.split())
			rot = tuple(float(s) for s in rs.split())
			scale = tuple(float(s) for s in ss.split())
			elas = float(es)
			fric = float(fs)

			if type.startswith('ball'):
				rs = input.readline()
				vs = input.readline()
				radius = float(rs)
				vel = [float(s) for s in vs.split()]
				obj = Ball(self.world, self.space, name, type, radius, mass, elas, fric)
				self.add(obj, pos, vel)
				assert(input.readline().strip() == '.')
			else:
				verts = []
				faces = []
				while True:
					l = input.readline()
					assert(l)
					if l.strip() == '.':
						break
					verts.append(tuple(float(s) for s in l.split()))
				
				while True:
					l = input.readline()
					assert(l)
					if l.strip() == '.':
						break
					f = tuple(int(s) for s in l.split())
					assert(len(f) >= 3)
					for v in f:
						assert(0 <= v < len(verts))
					faces.append(f)

				assert(len(verts) > 0 and len(faces) > 0)
				box_dims, offset = is_box(verts)
				if box_dims == None:
					print('{0} is a trimesh'.format(name))
					obj = Convex(self.world, self.space, name, type, verts, faces, elas, fric)
				else:
					print('{0} is a box'.format(name))
					obj = Box(self.world, self.space, name, type, box_dims, None, elas, fric)
					pos = tuple(pos[i] + offset[i] for i in range(3))
				
				self.add(obj, pos)
