#!/usr/bin/env python

from __future__ import print_function
import sys, os
import random
import sml


def make_rules(model_dims):
	model_rhs = ' '.join('(<c> ^create-model <m{0}>) (<m{0}> ^type em ^name {1})'.format(i, m) for i, m in enumerate(model_dims))
	rules = []
	rules.append('''
sp {{create-models
   (state <s> ^superstate nil
              ^svs <svs>)
   (<svs> ^spatial-scene <scn> ^command <c>)
   (<scn> ^child.id b1)
-->
   {0}
}}
'''.format(model_rhs))
	
	rules.append('''
sp {assign-models
   (state <s> ^superstate nil
              ^svs.command <c>)
   (<c> ^create-model <cm>)
   (<cm> ^name <name> ^status success)
-->
   (<c> ^assign-model <a>)
   (<a> ^name <name> ^inputs all ^outputs.<name> <d>)}
''')

	return rules

def output_handler(id, env, agent, phase):
	env.step()
	sgel = env.get_sgel()
	agent.SendSVSInput(sgel)
	
class Agent:
	def __init__(self, env, model_dims, test):
		self.env = env
		self.model_dims = model_dims
		self.test = test
		self.cli = sml.cli()
		self.agent = self.cli.agent
		self.kernel = self.cli.kernel
		self.output_event = None
	
	def reset(self):
		if self.output_event != None:
			self.agent.UnregisterForRunEvent(self.output_event)
		
		self.cli.execute('init')
		self.cli.execute('excise -a')
		self.cli.execute('waitsnc -e')
		for r in make_rules(self.model_dims):
			self.cli.execute(r)
		
		# Need to do this first step so that all velocities
		# have real values the first time Soar sees them
		self.env.step()
		init_input = self.env.get_sgel()
		self.agent.SendSVSInput(init_input)
		self.output_event = self.agent.RegisterForRunEvent(sml.sml.smlEVENT_AFTER_OUTPUT_PHASE, output_handler, self.env)

		self.cli.execute('run 2')
		
	def run(self):
		self.reset()
		self.cli.execute('svs learn on')
		if self.test:
			self.cli.execute('svs state.0.learn_models off')
			self.cli.execute('svs state.0.test_models on')
		else:
			self.cli.execute('svs state.0.learn_models on')
			self.cli.execute('svs state.0.test_models off')
		
		self.cli.repl()
