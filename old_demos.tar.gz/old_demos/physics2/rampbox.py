from __future__ import print_function
import sys, os
import random
import physics2 as physics
import agent

BALL_RADIUS = .25
BALL_MASS = 1
BALL_VEL = 40

RAMP_LENGTH = 4
RAMP_HEIGHT = 2

BOX_SIZE = 2
BOX_HSIZE = BOX_SIZE / 2
BOX_DIMS = [BOX_SIZE] * 3

MIN_SEP = 1
MAX_SEP = 2

RAMP_VERTS = [
	(0,           -1, 0          ), (0,           1, 0          ),
	(0,           -1, RAMP_HEIGHT), (0,           1, RAMP_HEIGHT),
	(RAMP_LENGTH, -1, 0          ), (RAMP_LENGTH, 1, 0          ) ]

ROOM_SIZE = 12
MIN_LEFT = 1
MAX_LEFT = 2

RAND_SEED = 0

def generate_env(offset, ramp_left_of_box, ramp_box_touch, ball_move_left, ball_pos):
	global RAND_SEED
	
	env = physics.Environment()
	
	#suf = str(RAND_SEED)
	suf = ''
	ball = physics.Ball(env.world, env.space, 'b1', 'ball', BALL_RADIUS, BALL_MASS, 0, 0)
	ramp = physics.Convex(env.world, env.space, 'ramp1' + suf, 'ramp', RAMP_VERTS, None, 0, 0)
	box = physics.Box(env.world, env.space, 'box1' + suf, 'box', BOX_DIMS, None, 0, 0)
	
	lw = physics.Box(env.world, env.space, 'lw' + suf, 'wall', (2, 2, ROOM_SIZE), None, 0, 0)
	rw = physics.Box(env.world, env.space, 'rw' + suf, 'wall', (2, 2, ROOM_SIZE), None, 0, 0)
	ceil = physics.Box(env.world, env.space, 'ceil1' + suf, 'ceiling', (ROOM_SIZE, 2, 2), None, 0, 0)
	floor = physics.Box(env.world, env.space, 'floor1' + suf, 'floor', (ROOM_SIZE, 2, 2), None, 0, 0)
	
	env.add(lw, (-1, 0, ROOM_SIZE / 2))
	env.add(rw, (ROOM_SIZE + 1, 0, ROOM_SIZE / 2))
	env.add(floor, (ROOM_SIZE / 2, 0, -1))
	env.add(ceil, (ROOM_SIZE / 2, 0, ROOM_SIZE + 1))
	
	if ramp_box_touch:
		sep = 0
	else:
		sep = random.uniform(MIN_SEP, MAX_SEP)
	
	left = random.uniform(MIN_LEFT, MAX_LEFT)
	
	ramp_extents = [0, 0]
	box_extents = [0, 0]

	if ramp_left_of_box:
		ramp_extents[0] = left
		ramp_extents[1] = ramp_extents[0] + RAMP_LENGTH
		box_extents[0] = ramp_extents[1] + sep
		box_extents[1] = box_extents[0] + BOX_SIZE
		mid_interval = [ ramp_extents[1], box_extents[0] ]
		right = box_extents[1]
	else:
		box_extents[0] = left
		box_extents[1] = box_extents[0] + BOX_SIZE
		ramp_extents[0] = box_extents[1] + sep
		ramp_extents[1] = ramp_extents[0] + RAMP_LENGTH
		mid_interval = [ box_extents[1], ramp_extents[0] ]
		right = ramp_extents[1]
	
	if ball_pos == 0:
		# left-most slot
		ballx = random.uniform(BALL_RADIUS, left - BALL_RADIUS)
		ballz = BALL_RADIUS
	elif ball_pos == 1:
		# on ramp
		ballx = (ramp_extents[0] + ramp_extents[1]) / 2.0
		ballz = BALL_RADIUS + RAMP_HEIGHT / 2.0
	elif ball_pos == 2:
		# on box
		ballx = (box_extents[0] + box_extents[1]) / 2.0
		ballz = BOX_SIZE + BALL_RADIUS
	elif ball_pos == 3:
		# between ramp and box
		if mid_interval[0] == mid_interval[1]:
			ballx = mid_interval[0]
			ballz = max(BOX_SIZE, RAMP_HEIGHT) + BALL_RADIUS
		else:
			ballx = random.uniform(mid_interval[0] + BALL_RADIUS, mid_interval[1] - BALL_RADIUS)
			ballz = BALL_RADIUS
	else:
		ballx = random.uniform(right + BALL_RADIUS, ROOM_SIZE - BALL_RADIUS)
		ballz = BALL_RADIUS
		
	env.add(ramp, (ramp_extents[0], 0, 0))
	env.add(box, (box_extents[0] + BOX_HSIZE, 0, BOX_HSIZE))
	
	if ball_move_left:
		env.add(ball, (ballx, 0, ballz), (-BALL_VEL, 0, 0))
	else:
		env.add(ball, (ballx, 0, ballz), (BALL_VEL, 0, 0))
	
	env.random_offset(offset)
	return env
	
if __name__ == '__main__':
	if len(sys.argv) < 4:
		print('usage: {} <model> <config> <seed> <offset>'.format(sys.argv[0]))
		sys.exit(1)
	
	model = sys.argv[1]
	config = int(sys.argv[2])
	RAND_SEED = int(sys.argv[3])
	random.seed(RAND_SEED)
	offset = float(sys.argv[4])

	ball_move_left   = (config & 1) == 0
	ramp_left_of_box = (config & 2) == 0
	ramp_box_touch   = (config & 4) == 0
	ball_pos         = (config >> 3) % 5
	env = generate_env(offset, ramp_left_of_box, ramp_box_touch, ball_move_left, ball_pos)
	a = agent.Agent(env, [model], False)
	a.run()
