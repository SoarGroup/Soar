from __future__ import print_function
import sys, os
import math
import random
import physics2 as physics
import agent

BALL_RADIUS = .25
BALL_MASS = 1
BALL_VEL = 40

MIN_SEP = 1
MAX_SEP = 2

FRICTIONS = [ 0 ]
ELASTICITIES = [ .3 ]
RAMP_ANGLES = [ 30, 45, 60 ]
SIZES = [1, 2, 3, 4]
RAMP_RATIO = 0.5

ROOM_SIZE = (10, 20)
BALL_POS = (5, 19)

name_counter = 0

def gen_ramp(world, space):
	global name_counter
	
	name = 'ramp{}'.format(name_counter)
	name_counter += 1
	
	angle = random.choice(RAMP_ANGLES)
	if angle <= 45:
		l = random.choice(SIZES)
		h = math.tan(math.radians(angle))
	else:
		h = random.choice(SIZES)
		l = h / math.tan(math.radians(angle))
	
	# ramp facing left or right
	if random.choice([True, False]):
		verts = [
			( 0, -1, 0 ), (0, 1, 0 ),
			( l, -1, 0 ), (l, 1, 0 ),
			( l, -1, h ), (l, 1, h ) ]
	else:
		verts = [
			( 0, -1, 0 ), (0, 1, 0 ),
			( l, -1, 0 ), (l, 1, 0 ),
			( 0, -1, h ), (0, 1, h ) ]

	elas = random.choice(ELASTICITIES)
	fric = random.choice(FRICTIONS)
	type = 'ramp_{}_{}_{}'.format(angle, elas, fric)
	
	obj = physics.Convex(world, space, name, type, verts, None, elas, fric)
	extents = (int(math.ceil(l)), int(math.ceil(h)))
	offset = (0, 0)
	
	return obj, extents, offset

def gen_box(world, space):
	global name_counter
	
	name = 'box{}'.format(name_counter)
	name_counter += 1
	
	h = random.choice(SIZES)
	w = random.choice(SIZES)
	
	elas = random.choice(ELASTICITIES)
	fric = random.choice(FRICTIONS)
	type = 'box_{}_{}'.format(elas, fric)
	
	obj = physics.Box(world, space, name, type, (w, 2, h), None, elas, fric)
	extents = (w, h)
	offset = (w / 2.0, h / 2.0)
	return obj, extents, offset

def gen_obj(world, space):
	if random.uniform(0, 1) < RAMP_RATIO:
		return gen_ramp(world, space)
	return gen_box(world, space)

def add_obj_at(env, x, y, occupied):
	if (x, y) in occupied:
		return False
	
	obj, extents, offset = gen_obj(env.world, env.space)
	new_occupied = []
	for i in range(extents[0] + 1):
		for j in range(extents[1] + 1):
			p = (x + i, y + j)
			if p in occupied:
				return False
			new_occupied.append(p)
	
	occupied.update(new_occupied)
	env.add(obj, (x + offset[0], 0, y + offset[1]))
	print('add {} at {}, {}'.format(obj.name, x, y))
	return True

def generate_env(seed):
	random.seed(seed)
	
	env = physics.Environment()
	
	ball = physics.Ball(env.world, env.space, 'b1', 'ball', BALL_RADIUS, BALL_MASS, 0, 0)
	env.add(ball, (BALL_POS[0], 0, BALL_POS[1]), (BALL_VEL, 0, 0))

	occupied = set()
	occupied.add(BALL_POS)
	for x in range(ROOM_SIZE[0]):
		for y in range(ROOM_SIZE[1]):
			add_obj_at(env, x, y, occupied)

	lw = physics.Box(env.world, env.space, 'lw', 'wall', (2, 2, ROOM_SIZE[1]), None, 0, 0)
	rw = physics.Box(env.world, env.space, 'rw', 'wall', (2, 2, ROOM_SIZE[1]), None, 0, 0)
	ceil = physics.Box(env.world, env.space, 'ceil', 'ceiling', (ROOM_SIZE[0], 2, 2), None, 0, 0)
	floor = physics.Box(env.world, env.space, 'floor', 'floor', (ROOM_SIZE[0], 2, 2), None, 0, 0)
	
	env.add(lw, (-1, 0, ROOM_SIZE[1] / 2))
	env.add(rw, (ROOM_SIZE[0] + 1, 0, ROOM_SIZE[1] / 2))
	env.add(floor, (ROOM_SIZE[0] / 2, 0, -1))
	env.add(ceil, (ROOM_SIZE[0] / 2, 0, ROOM_SIZE[1] + 1))
	
	return env
	
if __name__ == '__main__':
	if len(sys.argv) < 3:
		print('usage: {} <model> <random seed>'.format(sys.argv[0]))
		sys.exit(1)
	
	model = sys.argv[1]
	seed = hash(sys.argv[2])

	env = generate_env(seed)
	a = agent.Agent(env, [model], False)
	a.run()
