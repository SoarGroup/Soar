import bpy
import subprocess as proc
import testccd

def flip_quat(q):
	return (q[1], q[2], q[3], q[0])
	
# runs qhull to calculate convex hull of vertices
def convex_hull(verts):
	dims = len(verts[0])
	n = len(verts)
	
	vertlines = ['{} {} {}'.format(*v) for v in verts]
	input = '{}\n{}\n{}'.format(dims, n, '\n'.join(vertlines))
	qhull = proc.Popen("qconvex i Qt".split(), stdin=proc.PIPE, stdout=proc.PIPE, stderr=proc.PIPE)
	out, err = qhull.communicate(bytes(input, 'ascii'))
	if qhull.wait() != 0:
		print(err)
		print('qconvex exited with non-zero status')
		sys.exit(1)
	
	lines = list(filter(None, out.decode('ascii').split('\n')))
	triangles = []
	ntris = int(lines[0])
	for line in lines[1:]:
		# qconvex seems to return triangles in clockwise order, so reverse it
		triangles.append(tuple(reversed([int(x) for x in line.split()])))
	
	assert(len(triangles) == ntris)
	return triangles

def dump_obj(obj, f):
	set_default_props()
	print(obj.name, file=f)
	print(obj['type'], file=f)
	print(obj['mass'], file=f)
	print(' '.join(str(x) for x in obj.location), file=f)
	print(' '.join(str(x) for x in reversed(obj.rotation_euler)), file=f)
	print(' '.join(str(x) for x in obj.scale), file=f)
	print(obj['elasticity'], file=f)
	print(obj['friction'], file=f)

	if obj['type'].startswith('ball'):
		print(obj['radius'], file=f)
		print('{} {} {}'.format(obj['vx'], obj['vy'], obj['vz']), file=f)
	else:
		verts = [tuple(v.co) for v in obj.data.vertices]
		chull = convex_hull(verts)
		for v in verts:
			print(' '.join(str(x) for x in v), file=f)
		print('.', file=f)
		for t in chull:
			print(' '.join(str(i) for i in t), file=f)

	print('.', file=f)

def dump(path):
	f = open(path, 'w')
	for o in bpy.data.objects:
		dump_obj(o, f)

def set_default(obj, prop, val):
	if prop not in obj:
		obj[prop] = val
		
def set_default_props():
	for obj in bpy.data.objects:
		set_default(obj, 'type', 'obj')
		set_default(obj, 'mass', 0.0)
		set_default(obj, 'elasticity', 0.0)
		set_default(obj, 'friction', 0.0)
		if obj['type'].startswith('ball'):
			set_default(obj, 'radius', .25)
			for v in ['vx', 'vy', 'vz']:
				set_default(obj, v, 0.0)

def distance():
	sel = bpy.context.selected_objects
	if len(sel) < 2:
		print('select 2 objects')
		return
	
	reps = []
	for obj in sel:
		pos = tuple(obj.location)
		m = obj.rotation_mode
		obj.rotation_mode = 'QUATERNION'
		rot = flip_quat(obj.rotation_quaternion)
		obj.rotation_mode = m
		verts = []
		for v in obj.data.vertices:
			verts.extend(v.co)
		
		print('pos: {}'.format(pos))
		print('rot: {}'.format(rot))
		print('ver: {}'.format(verts))
		reps.append((verts, pos, rot))
	
	print(testccd.distance('cc', reps[0], reps[1]))
