This non-working version is where I was at when John said to try to get epmem queries in subgoals 
working instead.  The realization I was at was in order to get this to work I would have to store the 
results of retrievals on the top state to recover from GDS roll ups.   Ugly.